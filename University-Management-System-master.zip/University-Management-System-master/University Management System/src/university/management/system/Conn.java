package university.management.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conn {
    Connection c;
    Statement s;

    Conn() {
        try {
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/universitymanagementsystem", "postgres", "Shubham@187");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
